/*!
  Template program for the Computer Vision course.

  Author: Manuel J Marin-Jimenez, University of Cordoba

*/

#include <iostream>
#include <exception>
#include <sstream>

#include <opencv2/core/core.hpp>
#include <opencv2/core/utility.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>
//#include <opencv2/calib3d/calib3d.hpp>

#include "common_code.hpp"

const int mult_slider_max = 100;
int mult_slider;
double mult;

cv::Mat improc;

static void on_trackbar_mult(int, void*)
{
    mult = (double) mult_slider / mult_slider_max;
    
    // Do something to the proc image
    std::cout << mult << std::endl;
    // TO DO
    
    cv::imshow("Processed", improc);
}

int main (int argc, char* const* argv)
{
    int retCode = EXIT_SUCCESS;

    cv::Mat imorig(320, 480, CV_8UC3, cv::Scalar(0, 0, 255)); // Load from file instead of creating this one
    improc = imorig.clone();

    // Type your code here and within 'common_code.cpp' 

    cv::namedWindow("Original", cv::WINDOW_AUTOSIZE); // Create Window
    cv::namedWindow("Processed", cv::WINDOW_AUTOSIZE); // Create Window

    cv::createTrackbar("Mult", "Processed", &mult_slider, mult_slider_max, on_trackbar_mult);

    cv::imshow("Original", imorig);
    cv::imshow("Processed", improc);

    char key = 0;
    do {
        key = cv::waitKey(0);

    } while (key != 27);

    std::cout << "End of the process!" << std::endl;
    return retCode;
}

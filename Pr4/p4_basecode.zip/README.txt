Go to Moodle for details about the practical assignment.

Do not forget your video defending the assignment.


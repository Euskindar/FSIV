/*!
  Template program for the Computer Vision course.

  Author: Manuel J Marin-Jimenez, University of Cordoba

*/

#include <iostream>
#include <exception>
#include <sstream>

#include <opencv2/core/core.hpp>
#include <opencv2/core/utility.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>
//#include <opencv2/calib3d/calib3d.hpp>

#include "common_code.hpp"

int main (int argc, char* const* argv)
{
    int retCode = EXIT_SUCCESS;

    // Type your code here and within 'common_code.cpp' 


    std::cout << "End of the process!" << std::endl;
    return retCode;
}
